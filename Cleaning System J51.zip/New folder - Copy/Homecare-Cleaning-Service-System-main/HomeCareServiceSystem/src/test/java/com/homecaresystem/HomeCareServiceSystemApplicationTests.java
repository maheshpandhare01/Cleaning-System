package com.homecaresystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeCareServiceSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
