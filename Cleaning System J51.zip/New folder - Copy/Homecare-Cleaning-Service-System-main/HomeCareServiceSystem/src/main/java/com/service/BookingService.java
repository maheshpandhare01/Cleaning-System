package com.service;

import com.model.Booking;

public interface BookingService {
	
	public Booking addBooking(Booking b);

}
