package com.service;

import com.model.Cleaner;

public interface CleanerService {

	public Cleaner addCleaner(Cleaner c);
}
