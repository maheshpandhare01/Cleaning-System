package com.service;

import com.model.Payment;

public interface PaymentService {
	
	public Payment addPayment(Payment p);

}
