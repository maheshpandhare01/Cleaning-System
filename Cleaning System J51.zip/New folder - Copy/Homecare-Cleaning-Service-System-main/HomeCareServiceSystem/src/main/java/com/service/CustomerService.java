package com.service;

import com.model.Customer;

public interface CustomerService {
	
	public Customer addCustomer(Customer c);

}
