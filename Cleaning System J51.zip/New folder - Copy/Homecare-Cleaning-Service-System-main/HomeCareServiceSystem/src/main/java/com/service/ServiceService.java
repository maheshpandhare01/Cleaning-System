package com.service;

import com.model.Service;

public interface ServiceService {
	
	public Service addService(Service s);

}
