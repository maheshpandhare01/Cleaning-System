package com.service;

import com.model.Review;

public interface ReviewService {
	
	public Review addReview(Review  r);

}
